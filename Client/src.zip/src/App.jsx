import React, { useState, useEffect } from 'react';
import GameCanvas from "./components/GameCanvas";

export default function App() {
  const [gameState, setGameState] = useState("menu"); // "menu", "playing", "guide", "settings"
  const [volume, setVolume] = useState(80);
  const [sfx, setSfx] = useState(true);

  useEffect(() => {
    const handleExit = () => {
      setGameState("menu");
    };
    window.addEventListener("exit-to-menu", handleExit);
    return () => {
      window.removeEventListener("exit-to-menu", handleExit);
    };
  }, []);

  return (
    <div className="w-screen h-screen overflow-hidden bg-emerald-950 text-white font-sans select-none relative">
      {gameState === "menu" && (
        <div className="w-full h-full flex flex-col justify-between items-center p-8 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-emerald-900 via-emerald-950 to-black">
          {/* Logo */}
          <div className="mt-8 flex flex-col items-center">
            <img 
              src="/CozyPixel.png" 
              alt="Cozy Pixel Farm Logo" 
              className="w-80 md:w-96 drop-shadow-[0_8px_8px_rgba(0,0,0,0.5)] animate-bounce"
              style={{ animationDuration: '3s' }}
            />
            <p className="text-emerald-300 font-mono tracking-widest text-sm mt-4 font-bold text-center">
              PETUALANGAN BERTANI ISOMETRIK RETRO
            </p>
          </div>

          {/* Menu Buttons */}
          <div className="flex flex-col gap-4 w-64 md:w-80">
            <button 
              onClick={() => setGameState("playing")}
              className="w-full py-4 bg-amber-500 hover:bg-amber-400 active:scale-95 transition-all text-white font-bold text-lg rounded-2xl border-b-4 border-amber-700 shadow-lg cursor-pointer"
            >
              ▶ Mulai Bermain
            </button>
            <button 
              onClick={() => setGameState("guide")}
              className="w-full py-3 bg-emerald-700 hover:bg-emerald-600 active:scale-95 transition-all text-white font-semibold rounded-2xl border-b-4 border-emerald-900 shadow-md cursor-pointer"
            >
              📖 Cara Bermain
            </button>
            <button 
              onClick={() => setGameState("settings")}
              className="w-full py-3 bg-emerald-800 hover:bg-emerald-700 active:scale-95 transition-all text-white font-semibold rounded-2xl border-b-4 border-emerald-950 shadow-md cursor-pointer"
            >
              ⚙ Pengaturan
            </button>
          </div>

          {/* Footer / Move hint */}
          <div className="mb-4 text-emerald-500 text-xs font-mono text-center">
            Gunakan WASD/Arah untuk bergerak & E untuk interaksi
          </div>
        </div>
      )}

      {gameState === "guide" && (
        <div className="w-full h-full flex flex-col justify-center items-center p-6 bg-black/85 backdrop-blur-sm">
          <div className="max-w-md w-full bg-emerald-900 border-4 border-amber-500 p-6 rounded-3xl shadow-2xl relative">
            <h2 className="text-2xl font-bold text-amber-400 mb-4 text-center font-mono border-b-2 border-amber-600/40 pb-2">
              📖 CARA BERMAIN
            </h2>
            <div className="space-y-4 text-sm font-sans leading-relaxed text-emerald-100 overflow-y-auto max-h-[60vh] pr-2">
              <div>
                <p className="font-bold text-white mb-1">🎮 Kontrol Karakter</p>
                <p>Gunakan tombol <span className="bg-emerald-950 px-2 py-0.5 rounded font-mono border border-emerald-700 text-amber-300">WASD</span> atau <span className="bg-emerald-950 px-2 py-0.5 rounded font-mono border border-emerald-700 text-amber-300">Tombol Arah</span> untuk berjalan.</p>
                <p className="mt-1">Gunakan tombol <span className="bg-emerald-950 px-2 py-0.5 rounded font-mono border border-emerald-700 text-amber-300">E</span> untuk berinteraksi dengan Nenek atau Lahan Tanam.</p>
                <p className="mt-1">Tekan tombol <span className="bg-emerald-950 px-2 py-0.5 rounded font-mono border border-emerald-700 text-amber-300">ESC</span> selama bermain untuk kembali ke Menu Utama.</p>
              </div>
              <div className="border-t border-emerald-800 pt-3">
                <p className="font-bold text-white mb-1">🌾 Siklus Pertanian</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li><strong>Tanam:</strong> Berdirilah dekat lahan kosong, tekan E, lalu pilih benih yang ingin ditanam.</li>
                  <li><strong>Siram:</strong> Berdirilah dekat tanaman yang belum disiram, lalu tekan E untuk menyiram (memakan 5 Tenaga).</li>
                  <li><strong>Tidur:</strong> Gunakan tombol Tidur di pojok kiri bawah untuk mengganti hari. Hanya tanaman yang disiram yang akan tumbuh!</li>
                  <li><strong>Panen:</strong> Saat tanaman sudah matang, tekan E di dekatnya untuk memanen hasil pertanian.</li>
                </ul>
              </div>
              <div className="border-t border-emerald-800 pt-3">
                <p className="font-bold text-white mb-1">👵 Dapur & Misi Nenek</p>
                <p>Temui Nenek di samping rumah untuk berdialog. Anda juga bisa memasak Salad Segar atau Kentang Tumbuk menggunakan Dapur Masak di pojok kiri bawah, lalu menjualnya untuk mendapatkan koin tambahan.</p>
              </div>
            </div>
            <button 
              onClick={() => setGameState("menu")}
              className="mt-6 w-full py-3 bg-amber-500 hover:bg-amber-400 text-white font-bold rounded-2xl border-b-4 border-amber-700 shadow cursor-pointer transition-all active:scale-95"
            >
              Kembali ke Menu
            </button>
          </div>
        </div>
      )}

      {gameState === "settings" && (
        <div className="w-full h-full flex flex-col justify-center items-center p-6 bg-black/85 backdrop-blur-sm">
          <div className="max-w-md w-full bg-emerald-900 border-4 border-amber-500 p-6 rounded-3xl shadow-2xl relative">
            <h2 className="text-2xl font-bold text-amber-400 mb-4 text-center font-mono border-b-2 border-amber-600/40 pb-2">
              ⚙ PENGATURAN
            </h2>
            <div className="space-y-6 my-6">
              <div className="flex flex-col gap-2">
                <label className="text-sm font-semibold flex justify-between">
                  <span>Volume Suara</span>
                  <span className="text-amber-400 font-mono">{volume}%</span>
                </label>
                <input 
                  type="range" 
                  min="0" 
                  max="100" 
                  value={volume}
                  onChange={(e) => setVolume(e.target.value)}
                  className="w-full accent-amber-500 cursor-pointer h-2 bg-emerald-950 rounded-lg appearance-none"
                />
              </div>

              <div className="flex justify-between items-center bg-emerald-950 p-4 rounded-xl border border-emerald-800 font-sans">
                <span className="text-sm font-semibold">Efek Suara (SFX)</span>
                <button 
                  onClick={() => setSfx(!sfx)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold font-mono transition-all cursor-pointer ${sfx ? 'bg-amber-500 text-white' : 'bg-emerald-800 text-emerald-400'}`}
                >
                  {sfx ? "AKTIF" : "NONAKTIF"}
                </button>
              </div>
            </div>
            <button 
              onClick={() => setGameState("menu")}
              className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-white font-bold rounded-2xl border-b-4 border-amber-700 shadow cursor-pointer transition-all active:scale-95"
            >
              Simpan & Kembali
            </button>
          </div>
        </div>
      )}

      {gameState === "playing" && (
        <div className="w-full h-full relative">
          <GameCanvas />
        </div>
      )}
    </div>
  );
}
