const GameState = {
  day: 1,
  energy: 100,
  maxEnergy: 100,
  gold: 0,
  inventory: {
    turnip_seed: 5,
    potato_seed: 3,
    turnip: 0,
    potato: 0,
    salad: 0,
    mashed_potato: 0,
  },
  // Diisi ulang oleh FarmScene.create() saat scene dimulai — jangan isi
  // data statis di sini supaya tidak ada dua sumber kebenaran posisi plot.
  plots: [],
  quests: [
    { id: 1, title: 'Benih Pertama', desc: 'Tanam 3 tanaman (0/3)', goal: 3, progress: 0, done: false },
    { id: 2, title: 'Tangan Hijau', desc: 'Siram 2 hari berturut (0/2)', goal: 2, progress: 0, done: false },
    { id: 3, title: 'Panen Perdana', desc: 'Panen 3 tanaman (0/3)', goal: 3, progress: 0, done: false },
    { id: 4, title: 'Juru Masak', desc: 'Buat 1 masakan (0/1)', goal: 1, progress: 0, done: false },
    { id: 5, title: 'Bicara ke Teman', desc: 'Temui Teman di depan rumah', goal: 1, progress: 0, done: false },
  ],
  activeQuest: 0,
  wateredStreak: 0,
  hasWateredToday: false,
  onQuestComplete: null,

  addProgress(questIndex, amount = 1) {
    const q = this.quests[questIndex];
    if (q && !q.done) {
      q.progress = Math.min(q.progress + amount, q.goal);
      if (q.id === 1) q.desc = `Tanam 3 tanaman (${q.progress}/3)`;
      else if (q.id === 2) q.desc = `Siram 2 hari berturut (${q.progress}/2)`;
      else if (q.id === 3) q.desc = `Panen 3 tanaman (${q.progress}/3)`;
      else if (q.id === 4) q.desc = `Buat 1 masakan (${q.progress}/1)`;

      if (q.progress >= q.goal) {
        q.done = true;
        this.activeQuest++;
        if (typeof this.onQuestComplete === 'function') {
          this.onQuestComplete(q.title);
        }
      }
    }
  }
};

export default GameState;