import Phaser from 'phaser';
import GameState from '../systems/GameState';

export default class HUDScene extends Phaser.Scene {
  constructor() {
    super('HUDScene');
    this.infoPanelOpen = false;
    this.infoPanel = [];
    this.craftListContainer = null;
  }

  create() {
    // Reset state variables
    this.infoPanelOpen = false;
    this.infoPanel = [];

    this.updateHUDText();

    // Refresh HUD stats every 500ms
    this.hudTimer = this.time.addEvent({
      delay: 500,
      callback: this.updateHUDText,
      callbackScope: this,
      loop: true
    });

    // Hook quest completion overlay banner in HUDScene
    GameState.onQuestComplete = (title) => {
      this.showQuestCompleteBanner(title);
    };

    // ESC key listener to return to Menu
    this.input.keyboard.on('keydown-ESC', () => {
      this.scene.stop('HUDScene');
      this.scene.stop('FarmScene');
      window.dispatchEvent(new CustomEvent("exit-to-menu"));
    });
  }

  updateHUDText() {
    const width = this.scale.width;
    const height = this.scale.height;

    // Create UI elements if they do not exist
    if (!this.dayText) {
      // Hari Counter (Safe area 32px from left, 32px from top)
      this.dayText = this.add.text(32, 32, "", { 
        fontSize: "14px", 
        fontFamily: "Arial", 
        fontStyle: "bold", 
        color: "#ffffff" 
      }).setDepth(100);
      
      // Tenaga Label
      this.energyLabel = this.add.text(32, 54, "⚡ Tenaga", { 
        fontSize: "12px", 
        fontFamily: "Arial", 
        color: "#ffffff" 
      }).setDepth(100);

      this.energyBg = this.add.graphics().setDepth(99);
      this.energyFill = this.add.graphics().setDepth(100);

      // Gold / Koin Counter (Safe area 32px from right, 32px from top)
      this.goldText = this.add.text(width - 32, 32, "", { 
        fontSize: "14px", 
        fontFamily: "Arial", 
        fontStyle: "bold", 
        color: "#f5c45e" 
      }).setOrigin(1, 0).setDepth(100);

      // Inventory Summary
      this.inventoryText = this.add.text(width - 32, 54, "", { 
        fontSize: "12px", 
        fontFamily: "Arial", 
        color: "#cbd5e1" 
      }).setOrigin(1, 0).setDepth(100);
      
      // Quest Box
      this.questBox = this.add.graphics().setDepth(90);
      
      this.questTitle = this.add.text(width - 172, height - 134, "", { 
        fontSize: "12px", 
        fontFamily: "Arial", 
        fontStyle: "bold", 
        color: "#ffffff" 
      }).setOrigin(0.5).setDepth(91);

      this.questProgress = this.add.text(width - 172, height - 112, "", { 
        fontSize: "11px", 
        fontFamily: "Arial", 
        color: "#94a3b8" 
      }).setOrigin(0.5).setDepth(91);

      // Hint (Safe area 32px from right and bottom)
      this.controlsHint = this.add.text(width - 32, height - 32, "E — Interaksi   ESC — Menu", { 
        fontSize: "11px", 
        fontFamily: "Arial", 
        color: "#888888" 
      }).setOrigin(1, 0.5).setDepth(100);

      // Tidur Button (Safe area 32px from left, 48px from bottom)
      this.sleepBtn = this.add.text(32, height - 48, "💤 Tidur", {
        fontSize: "13px",
        fontFamily: "Arial",
        fontStyle: "bold",
        backgroundColor: "#1e293b",
        padding: { x: 12, y: 6 },
        color: "#ffffff"
      }).setOrigin(0, 0.5).setInteractive({ useHandCursor: true }).setDepth(100);

      this.sleepBtn.on('pointerdown', () => this.triggerSleep());
      this.sleepBtn.on('pointerover', () => this.sleepBtn.setStyle({ backgroundColor: "#334155" }));
      this.sleepBtn.on('pointerout', () => this.sleepBtn.setStyle({ backgroundColor: "#1e293b" }));

      // Memasak Button (Safe area 32px from left, 88px from bottom)
      this.craftBtn = this.add.text(32, height - 88, "🍳 Memasak", {
        fontSize: "13px",
        fontFamily: "Arial",
        fontStyle: "bold",
        backgroundColor: "#1e293b",
        padding: { x: 12, y: 6 },
        color: "#ffffff"
      }).setOrigin(0, 0.5).setInteractive({ useHandCursor: true }).setDepth(100);

      this.craftBtn.on('pointerdown', () => this.showCraftingPanel());
      this.craftBtn.on('pointerover', () => this.craftBtn.setStyle({ backgroundColor: "#334155" }));
      this.craftBtn.on('pointerout', () => this.craftBtn.setStyle({ backgroundColor: "#1e293b" }));

      // Info Button "?" (Top-right, left of Gold counter with safe spacing)
      this.infoBtnBg = this.add.graphics().setScrollFactor(0).setDepth(100);
      this.infoBtnBg.fillStyle(0x3b82f6, 1);
      this.infoBtnBg.fillCircle(width - 200, 36, 16);

      this.infoBtnText = this.add.text(width - 200, 36, "?", {
        fontSize: "16px",
        fontStyle: "bold",
        color: "#ffffff",
        fontFamily: "Arial"
      }).setOrigin(0.5).setScrollFactor(0).setDepth(101);

      this.infoBtnZone = this.add.zone(width - 200, 36, 32, 32)
        .setScrollFactor(0).setDepth(102).setInteractive({ useHandCursor: true });

      this.infoBtnZone.on("pointerup", () => this.toggleInfoPanel());
    }

    // Reposition elements responsively on screen size change
    this.goldText.setX(width - 32);
    this.inventoryText.setX(width - 32);
    this.controlsHint.setPosition(width - 32, height - 32);
    this.sleepBtn.setY(height - 48);
    this.craftBtn.setY(height - 88);
    
    this.infoBtnBg.clear();
    this.infoBtnBg.fillStyle(0x3b82f6, 1);
    this.infoBtnBg.fillCircle(width - 200, 36, 16);
    this.infoBtnText.setPosition(width - 200, 36);
    this.infoBtnZone.setPosition(width - 200, 36);

    // Update Text Content (Bahasa Indonesia)
    this.dayText.setText(`☀ Hari ${GameState.day}`);
    this.goldText.setText(`🪙 ${GameState.gold} Koin`);

    // Redraw Energy Bar
    this.energyFill.clear();
    this.energyBg.clear();
    
    this.energyBg.fillStyle(0x1e293b, 1);
    this.energyBg.fillRoundedRect(32, 70, 150, 12, 3);
    
    const energyPct = Math.max(0, Math.min(1, GameState.energy / GameState.maxEnergy));
    if (energyPct > 0) {
      this.energyFill.fillStyle(0x4ade80, 1); // bright green
      this.energyFill.fillRoundedRect(32, 70, 150 * energyPct, 12, 3);
    }

    // Format Inventory in Indonesian
    let invItems = [];
    if (GameState.inventory.turnip_seed > 0) invItems.push(`🌱 Benih Lobak x${GameState.inventory.turnip_seed}`);
    if (GameState.inventory.potato_seed > 0) invItems.push(`🥔 Benih Kentang x${GameState.inventory.potato_seed}`);
    if (GameState.inventory.turnip > 0) invItems.push(`🥗 Lobak x${GameState.inventory.turnip}`);
    if (GameState.inventory.potato > 0) invItems.push(`🥔 Kentang x${GameState.inventory.potato}`);
    if (GameState.inventory.salad > 0) invItems.push(`🥗 Salad Segar x${GameState.inventory.salad}`);
    if (GameState.inventory.mashed_potato > 0) invItems.push(`🍳 Kentang Tumbuk x${GameState.inventory.mashed_potato}`);
    
    this.inventoryText.setText(invItems.length > 0 ? invItems.join('  ') : "(Tas Kosong)");

    // Redraw Quest Box in Bottom-Right (Safe area 32px)
    this.questBox.clear();
    const boxW = 280;
    const boxH = 60;
    const boxX = width - boxW - 32;
    const boxY = height - boxH - 60; // Sits above controlsHint
    this.questBox.fillStyle(0x000000, 0.75);
    this.questBox.fillRoundedRect(boxX, boxY, boxW, boxH, 8);
    this.questBox.lineStyle(1, 0x334155, 1);
    this.questBox.strokeRoundedRect(boxX, boxY, boxW, boxH, 8);

    this.questTitle.setX(boxX + boxW / 2).setY(boxY + 18);
    this.questProgress.setX(boxX + boxW / 2).setY(boxY + 40);

    if (GameState.activeQuest < GameState.quests.length) {
      const q = GameState.quests[GameState.activeQuest];
      this.questTitle.setText(`📋 Misi Aktif: ${q.title}`);
      this.questProgress.setText(q.desc);
    } else {
      this.questTitle.setText("🎉 Semua misi selesai!");
      this.questProgress.setText("Kamu adalah petani pixel legendaris!");
    }
  }

  triggerSleep() {
    GameState.day += 1;
    GameState.energy = 100;

    // Crop Growth Calculations
    GameState.plots.forEach(plot => {
      if (plot.state === 'watered') {
        plot.daysGrown += 1;
        if (plot.daysGrown >= plot.growthDays[plot.crop]) {
          plot.state = 'ready';
        } else {
          plot.state = 'planted'; // Stays planted but needs watering today
        }
      } else if (plot.state === 'planted') {
        // Dry plot, does not grow today
      }
    });

    // Quest 2 streak logic
    if (GameState.hasWateredToday) {
      GameState.wateredStreak += 1;
      GameState.addProgress(1, 1);
    } else {
      GameState.wateredStreak = 0;
    }
    GameState.hasWateredToday = false;

    // Screen Fade / Transition (Bahasa Indonesia)
    const screenWidth = this.scale.width;
    const screenHeight = this.scale.height;

    const transitionBg = this.add.rectangle(0, 0, screenWidth, screenHeight, 0x000000, 0)
      .setOrigin(0)
      .setDepth(500);

    const transitionText = this.add.text(screenWidth / 2, screenHeight / 2, `☀ Hari ${GameState.day} dimulai...`, {
      fontSize: "20px",
      fontFamily: "'Press Start 2P', monospace",
      color: "#ffffff"
    }).setOrigin(0.5).setDepth(501).setAlpha(0);

    this.tweens.add({
      targets: transitionBg,
      fillAlpha: 0.9,
      duration: 500,
      yoyo: true,
      hold: 1000,
      repeat: 0,
      onYoyo: () => {
        this.updateHUDText();
        const farmScene = this.scene.get('FarmScene');
        if (farmScene) {
          GameState.plots.forEach(plot => {
            farmScene.updatePlotSprite(plot);
          });
          farmScene.cameras.main.fadeIn(600, 0, 0, 0);
          farmScene.showFloatingText(farmScene.player.x, farmScene.player.y - 30, `Hari ${GameState.day}`, "#e8a838");
        }
      },
      onComplete: () => {
        transitionBg.destroy();
      }
    });

    this.tweens.add({
      targets: transitionText,
      alpha: 1,
      duration: 500,
      yoyo: true,
      hold: 1000,
      repeat: 0,
      onComplete: () => {
        transitionText.destroy();
      }
    });
  }

  showQuestCompleteBanner(title) {
    const screenWidth = this.scale.width;
    const banner = this.add.container(screenWidth / 2, -60).setDepth(800);
    
    const bg = this.add.graphics();
    bg.fillStyle(0xf5c45e, 1);
    bg.fillRoundedRect(-180, -25, 360, 52, 8);
    bg.lineStyle(2, 0x78350f, 1);
    bg.strokeRoundedRect(-180, -25, 360, 52, 8);
    banner.add(bg);

    const checkText = this.add.text(0, -10, "✅ Misi Selesai!", {
      fontSize: "11px",
      fontFamily: "'Press Start 2P', monospace",
      color: "#78350f",
      fontStyle: "bold"
    }).setOrigin(0.5);

    const titleText = this.add.text(0, 11, title, {
      fontSize: "12px",
      fontFamily: "Arial",
      color: "#000000",
      fontStyle: "bold"
    }).setOrigin(0.5);

    banner.add([checkText, titleText]);

    this.tweens.add({
      targets: banner,
      y: 50,
      duration: 500,
      ease: "Back.easeOut",
      onComplete: () => {
        this.time.delayedCall(2500, () => {
          if (banner) {
            this.tweens.add({
              targets: banner,
              y: -60,
              duration: 400,
              ease: "Power1",
              onComplete: () => {
                banner.destroy();
              }
            });
          }
        });
      }
    });
  }

  showCraftingPanel() {
    const farmScene = this.scene.get('FarmScene');
    if (farmScene) {
      farmScene.movementLocked = true;
      farmScene.player.setVelocity(0, 0);
      farmScene.player.anims.play('idle-down');
    }

    const screenWidth = this.scale.width;
    const screenHeight = this.scale.height;

    const panel = this.add.container(screenWidth / 2, screenHeight / 2).setDepth(600);

    const cover = this.add.rectangle(-screenWidth / 2, -screenHeight / 2, screenWidth, screenHeight, 0x000000, 0.6)
      .setOrigin(0)
      .setInteractive();
    panel.add(cover);

    const boxWidth = 440;
    const boxHeight = 360;
    
    const box = this.add.graphics();
    box.fillStyle(0x0f172a, 0.95);
    box.fillRoundedRect(-boxWidth/2, -boxHeight/2, boxWidth, boxHeight, 16);
    box.lineStyle(3, 0xe8a838, 1);
    box.strokeRoundedRect(-boxWidth/2, -boxHeight/2, boxWidth, boxHeight, 16);
    panel.add(box);

    const titleText = this.add.text(0, -boxHeight/2 + 25, "Dapur Masak 🍳", {
      fontSize: "18px",
      fontFamily: "Arial",
      fontStyle: "bold",
      color: "#ffffff"
    }).setOrigin(0.5);
    panel.add(titleText);

    const closeBtn = this.add.text(boxWidth/2 - 30, -boxHeight/2 + 25, "✖", {
      fontSize: "18px",
      fontFamily: "Arial",
      fontStyle: "bold",
      color: "#94a3b8"
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });
    panel.add(closeBtn);

    const closePanel = () => {
      panel.destroy();
      if (farmScene) {
        farmScene.movementLocked = false;
      }
    };

    closeBtn.on('pointerdown', closePanel);
    cover.on('pointerdown', closePanel);

    this.drawCraftingContent(panel, boxWidth, boxHeight, closePanel);
  }

  drawCraftingContent(panel, boxWidth, boxHeight, closePanel) {
    if (this.craftListContainer) {
      this.craftListContainer.destroy();
    }
    this.craftListContainer = this.add.container(0, 0);
    panel.add(this.craftListContainer);

    // Recipes Column Left (Indonesian)
    this.add.text(-120, -boxHeight/2 + 65, "Resep Masakan", {
      fontSize: "14px",
      fontFamily: "Arial",
      fontStyle: "bold",
      color: "#f5c45e"
    }).setOrigin(0.5).setParentContainer(this.craftListContainer);

    // Salad
    const turnips = GameState.inventory.turnip;
    const canSalad = turnips >= 2;
    this.add.text(-120, -boxHeight/2 + 105, `🥗 Salad Segar (Hasil 1)\nButuh: 2 Lobak (${turnips}/2)`, {
      fontSize: "11px",
      fontFamily: "Arial",
      color: "#cbd5e1",
      align: "center"
    }).setOrigin(0.5).setParentContainer(this.craftListContainer);

    const saladCookBtn = this.add.text(-120, -boxHeight/2 + 145, "Masak Salad", {
      fontSize: "11px",
      fontFamily: "Arial",
      fontStyle: "bold",
      backgroundColor: canSalad ? "#10b981" : "#475569",
      padding: { x: 10, y: 5 },
      color: "#ffffff"
    }).setOrigin(0.5).setInteractive(canSalad ? { useHandCursor: true } : {}).setParentContainer(this.craftListContainer);

    if (canSalad) {
      saladCookBtn.on('pointerdown', () => {
        GameState.inventory.turnip -= 2;
        GameState.inventory.salad += 1;
        GameState.addProgress(3, 1); // quest 4 progress
        this.showFloatingText(this.scale.width / 2, this.scale.height / 2 - 120, "+1 Salad Segar dimasak!", "#10b981");
        this.drawCraftingContent(panel, boxWidth, boxHeight, closePanel);
        this.updateHUDText();
      });
    }

    // Mashed Potato
    const potatoes = GameState.inventory.potato;
    const canMashed = potatoes >= 2;
    this.add.text(-120, -boxHeight/2 + 205, `🥔 Kentang Tumbuk\nButuh: 2 Kentang (${potatoes}/2)`, {
      fontSize: "11px",
      fontFamily: "Arial",
      color: "#cbd5e1",
      align: "center"
    }).setOrigin(0.5).setParentContainer(this.craftListContainer);

    const mashedCookBtn = this.add.text(-120, -boxHeight/2 + 245, "Masak Kentang", {
      fontSize: "11px",
      fontFamily: "Arial",
      fontStyle: "bold",
      backgroundColor: canMashed ? "#10b981" : "#475569",
      padding: { x: 10, y: 5 },
      color: "#ffffff"
    }).setOrigin(0.5).setInteractive(canMashed ? { useHandCursor: true } : {}).setParentContainer(this.craftListContainer);

    if (canMashed) {
      mashedCookBtn.on('pointerdown', () => {
        GameState.inventory.potato -= 2;
        GameState.inventory.mashed_potato += 1;
        GameState.addProgress(3, 1);
        this.showFloatingText(this.scale.width / 2, this.scale.height / 2 - 120, "+1 Kentang Tumbuk dimasak!", "#10b981");
        this.drawCraftingContent(panel, boxWidth, boxHeight, closePanel);
        this.updateHUDText();
      });
    }

    // Shop Column Right (Selling Items - Indonesian)
    this.add.text(120, -boxHeight/2 + 65, "Jual Barang", {
      fontSize: "14px",
      fontFamily: "Arial",
      fontStyle: "bold",
      color: "#f5c45e"
    }).setOrigin(0.5).setParentContainer(this.craftListContainer);

    // Turnip Sell
    const turnipQty = GameState.inventory.turnip;
    const canSellTurnip = turnipQty > 0;
    this.add.text(120, -boxHeight/2 + 105, `Lobak: ${turnipQty}\n(Jual: 10 Koin)`, {
      fontSize: "11px",
      fontFamily: "Arial",
      color: "#cbd5e1",
      align: "center"
    }).setOrigin(0.5).setParentContainer(this.craftListContainer);

    const sellTurnipBtn = this.add.text(120, -boxHeight/2 + 140, "Jual 1", {
      fontSize: "10px",
      fontFamily: "Arial",
      fontStyle: "bold",
      backgroundColor: canSellTurnip ? "#e8a838" : "#475569",
      padding: { x: 8, y: 4 },
      color: "#ffffff"
    }).setOrigin(0.5).setInteractive(canSellTurnip ? { useHandCursor: true } : {}).setParentContainer(this.craftListContainer);

    if (canSellTurnip) {
      sellTurnipBtn.on('pointerdown', () => {
        GameState.inventory.turnip -= 1;
        GameState.gold += 10;
        this.drawCraftingContent(panel, boxWidth, boxHeight, closePanel);
        this.updateHUDText();
      });
    }

    // Potato Sell
    const potatoQty = GameState.inventory.potato;
    const canSellPotato = potatoQty > 0;
    this.add.text(120, -boxHeight/2 + 175, `Kentang: ${potatoQty}\n(Jual: 15 Koin)`, {
      fontSize: "11px",
      fontFamily: "Arial",
      color: "#cbd5e1",
      align: "center"
    }).setOrigin(0.5).setParentContainer(this.craftListContainer);

    const sellPotatoBtn = this.add.text(120, -boxHeight/2 + 210, "Jual 1", {
      fontSize: "10px",
      fontFamily: "Arial",
      fontStyle: "bold",
      backgroundColor: canSellPotato ? "#e8a838" : "#475569",
      padding: { x: 8, y: 4 },
      color: "#ffffff"
    }).setOrigin(0.5).setInteractive(canSellPotato ? { useHandCursor: true } : {}).setParentContainer(this.craftListContainer);

    if (canSellPotato) {
      sellPotatoBtn.on('pointerdown', () => {
        GameState.inventory.potato -= 1;
        GameState.gold += 15;
        this.drawCraftingContent(panel, boxWidth, boxHeight, closePanel);
        this.updateHUDText();
      });
    }

    // Salad Sell
    const saladQty = GameState.inventory.salad;
    const canSellSalad = saladQty > 0;
    this.add.text(120, -boxHeight/2 + 245, `Salad Segar: ${saladQty}\n(Jual: 35 Koin)`, {
      fontSize: "11px",
      fontFamily: "Arial",
      color: "#cbd5e1",
      align: "center"
    }).setOrigin(0.5).setParentContainer(this.craftListContainer);

    const sellSaladBtn = this.add.text(120, -boxHeight/2 + 275, "Jual 1", {
      fontSize: "10px",
      fontFamily: "Arial",
      fontStyle: "bold",
      backgroundColor: canSellSalad ? "#e8a838" : "#475569",
      padding: { x: 8, y: 4 },
      color: "#ffffff"
    }).setOrigin(0.5).setInteractive(canSellSalad ? { useHandCursor: true } : {}).setParentContainer(this.craftListContainer);

    if (canSellSalad) {
      sellSaladBtn.on('pointerdown', () => {
        GameState.inventory.salad -= 1;
        GameState.gold += 35;
        this.drawCraftingContent(panel, boxWidth, boxHeight, closePanel);
        this.updateHUDText();
      });
    }

    // Mashed Potato Sell
    const mashedQty = GameState.inventory.mashed_potato;
    const canSellMashed = mashedQty > 0;
    this.add.text(120, -boxHeight/2 + 305, `Kentang Tumbuk: ${mashedQty}\n(Jual: 45 Koin)`, {
      fontSize: "11px",
      fontFamily: "Arial",
      color: "#cbd5e1",
      align: "center"
    }).setOrigin(0.5).setParentContainer(this.craftListContainer);

    const sellMashedBtn = this.add.text(120, -boxHeight/2 + 335, "Jual 1", {
      fontSize: "10px",
      fontFamily: "Arial",
      fontStyle: "bold",
      backgroundColor: canSellMashed ? "#e8a838" : "#475569",
      padding: { x: 8, y: 4 },
      color: "#ffffff"
    }).setOrigin(0.5).setInteractive(canSellMashed ? { useHandCursor: true } : {}).setParentContainer(this.craftListContainer);

    if (canSellMashed) {
      sellMashedBtn.on('pointerdown', () => {
        GameState.inventory.mashed_potato -= 1;
        GameState.gold += 45;
        this.drawCraftingContent(panel, boxWidth, boxHeight, closePanel);
        this.updateHUDText();
      });
    }
  }

  toggleInfoPanel() {
    if (this.infoPanelOpen) {
      this.infoPanel.forEach(obj => obj.destroy());
      this.infoPanel = [];
      this.infoPanelOpen = false;
      
      // Unlock FarmScene controls
      const farmScene = this.scene.get('FarmScene');
      if (farmScene) farmScene.movementLocked = false;
      return;
    }
    
    this.infoPanelOpen = true;
    this.infoPanel = [];

    // Lock FarmScene controls while viewing panel
    const farmScene = this.scene.get('FarmScene');
    if (farmScene) {
      farmScene.movementLocked = true;
      farmScene.player.setVelocity(0, 0);
      farmScene.player.anims.play('idle-down');
    }

    const sw = this.cameras.main.width;
    const sh = this.cameras.main.height;

    // Help panel background box
    const bg = this.add.graphics().setScrollFactor(0).setDepth(150);
    bg.fillStyle(0x1a1a2e, 0.95);
    bg.fillRoundedRect(sw/2 - 200, sh/2 - 220, 400, 440, 16);
    bg.lineStyle(2, 0xe8a838);
    bg.strokeRoundedRect(sw/2 - 200, sh/2 - 220, 400, 440, 16);
    this.infoPanel.push(bg);

    const title = this.add.text(sw/2, sh/2 - 200, "📖 Petunjuk Bermain", {
      fontSize: "16px", fontStyle: "bold", color: "#f5c45e", fontFamily: "Arial"
    }).setOrigin(0.5).setScrollFactor(0).setDepth(151);
    this.infoPanel.push(title);

    const lines = [
      "🕹️ KONTROL",
      "WASD / ↑↓←→ : Gerakkan karakter",
      "E            : Interaksi / Bicara",
      "",
      "🌱 CARA BERMAIN",
      "1. Dekati lahan coklat → tekan E → pilih benih",
      "2. Keesokan harinya → tekan E → siram tanaman",
      "3. Setelah matang → tekan E → panen hasil",
      "4. Klik Memasak untuk olah hasil panen",
      "5. Bicara ke Nenek untuk misi & hadiah",
      "",
      "📋 MISI",
      "Selesaikan 5 misi untuk menang!",
      "",
      "💡 TIPS",
      "Klik Tidur untuk ke hari berikutnya",
      "Tenaga habis? Tidur dulu untuk isi ulang",
    ];

    lines.forEach((line, i) => {
      const color = line.startsWith("🕹️") || line.startsWith("🌱") ||
                    line.startsWith("📋") || line.startsWith("💡")
        ? "#f5c45e" : "#ffffff";
      const bold = color !== "#ffffff";
      const txt = this.add.text(sw/2 - 175, sh/2 - 165 + i * 22, line, {
        fontSize: "12px", color, fontFamily: "Arial",
        fontStyle: bold ? "bold" : "normal"
      }).setScrollFactor(0).setDepth(151);
      this.infoPanel.push(txt);
    });

    // Close button
    const closeBg = this.add.graphics().setScrollFactor(0).setDepth(151);
    closeBg.fillStyle(0xe8a838);
    closeBg.fillRoundedRect(sw/2 - 50, sh/2 + 185, 100, 30, 8);
    this.infoPanel.push(closeBg);

    const closeText = this.add.text(sw/2, sh/2 + 200, "Tutup", {
      fontSize: "13px", color: "#ffffff", fontStyle: "bold", fontFamily: "Arial"
    }).setOrigin(0.5).setScrollFactor(0).setDepth(152);
    this.infoPanel.push(closeText);

    const closeZone = this.add.zone(sw/2, sh/2 + 200, 100, 30)
      .setScrollFactor(0).setDepth(153).setInteractive({ useHandCursor: true });
    closeZone.on("pointerup", () => this.toggleInfoPanel());
    this.infoPanel.push(closeZone);
  }

  showFloatingText(x, y, text, color = '#ffffff') {
    const t = this.add.text(x, y, text, { 
      fontSize: "14px", 
      color, 
      fontStyle: "bold", 
      stroke: "#000000", 
      strokeThickness: 3 
    });
    t.setDepth(1000);
    this.tweens.add({ 
      targets: t, 
      y: y - 60, 
      alpha: 0, 
      duration: 1200, 
      ease: "Power2", 
      onComplete: () => t.destroy() 
    });
  }
}
