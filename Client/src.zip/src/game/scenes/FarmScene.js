import Phaser from 'phaser';
import GameState from '../systems/GameState';
import { PLAYER_CONFIG } from '../config/assetConfig';

// === Grid isometrik logis — final on-screen, TANPA perkalian *2 lagi ===
// (Bug sebelumnya: koordinat sudah dianggap "final" lalu dikali 2 lagi,
// jadi jarak antar-objek 2x lebih lebar dari ukuran sprite-nya sendiri.)
const TILE_W = 64;
const TILE_H = 32;
const ORIGIN_X = 760;
const ORIGIN_Y = 140;
const SPRITE_SCALE = 2;

function tileToWorld(col, row) {
  return {
    x: ORIGIN_X + (col - row) * (TILE_W / 2),
    y: ORIGIN_Y + (col + row) * (TILE_H / 2)
  };
}

function depthForY(y, bonus = 0) {
  return 200 + y * 0.1 + bonus;
}

export default class FarmScene extends Phaser.Scene {
  constructor() {
    super('FarmScene');
    this.player = null;
    this.cursors = null;
    this.wasd = null;
    this.lastDir = 'down';
    this.dialogOpen = false;
    this.movementLocked = false;
    this.plotGraphics = [];
    this.activePlantMenu = null;
  }

  create() {
    this.cameras.main.fadeIn(600, 0, 0, 0);

    const worldW = 1700;
    const worldH = 1100;

    // === LANTAI: solid fill. Asset ini TIDAK punya tile rumput yang bisa
    // diulang tanpa jahitan, jadi base lantai dipakai warna solid agar
    // tidak ada celah/zigzag sama sekali. ===
    this.add.rectangle(0, 0, worldW, worldH, 0x6fae4a).setOrigin(0).setDepth(0);

    // Variasi halus: bayangan diamond gelap acak (programmatic, bukan sprite)
    // supaya lantai tidak terlihat flat datar tanpa harus pakai asset rumput
    // yang rusak.
    const shadeGfx = this.add.graphics().setDepth(1);
    shadeGfx.fillStyle(0x5f9b3f, 0.35);
    for (let i = 0; i < 60; i++) {
      const sx = Phaser.Math.Between(40, worldW - 40);
      const sy = Phaser.Math.Between(40, worldH - 40);
      const w = Phaser.Math.Between(20, 40);
      shadeGfx.fillEllipse(sx, sy, w, w * 0.5);
    }

    // Sedikit aksen rumput dekoratif (wisp), jarang & acak, bukan fill penuh
    const wispKeys = [
      'grass_wisp_6', 'grass_wisp_8', 'grass_wisp_9',
      'grass_wisp_10', 'grass_wisp_11', 'grass_wisp_14'
    ];
    for (let i = 0; i < 18; i++) {
      const sx = Phaser.Math.Between(40, worldW - 40);
      const sy = Phaser.Math.Between(40, worldH - 40);
      const key = wispKeys[Phaser.Math.Between(0, wispKeys.length - 1)];
      this.add.image(sx, sy, 'terrain', key)
        .setOrigin(0.5, 1)
        .setScale(SPRITE_SCALE)
        .setAlpha(0.85)
        .setDepth(2);
    }

    this.treeColliders = this.physics.add.staticGroup();

    // === Lahan tanam: grid 3x3 rapi pakai diamond soil asli ===
    const plotDefs = [];
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 3; c++) {
        plotDefs.push([2 + c, 7 + r]);
      }
    }

    GameState.plots = [];
    let id = 0;
    plotDefs.forEach(([col, row]) => {
      const { x, y } = tileToWorld(col, row);
      GameState.plots.push({
        id: id++, col, row, x, y,
        state: 'empty', crop: null, daysGrown: 0,
        growthDays: { turnip: 2, potato: 3 },
        sprite: null
      });
    });

    // Pagar mengelilingi lahan 3x3 (col 2-4, row 7-9), gap di tengah row 8 col 1 sbg pintu masuk
    this.addFence(1, 6, 5, 10);

    this.createFarmPlots();

    // Pohon — SEKARANG SATU SPRITE UTUH, tidak dirakit dari beberapa frame
    this.placeTree(6, 4);
    this.placeTree(13, 4);
    this.placeTree(3, 3);

    // Dekorasi tambahan dari Objects.png (koordinat asli)
    this.placeDecor(15, 9, 'stone_large', 1.0);
    this.placeDecor(16, 10, 'stone_small', 1.0);
    this.placeDecor(14, 11, 'bush_green', 1.0);
    this.placeDecor(4, 11, 'bush_green', 1.0);
    this.placeDecor(1, 9, 'log_small', 1.0);
    this.placeDecor(15, 7, 'crystal_teal', 1.0);
    this.placeDecor(16, 8, 'leaf_plant', 1.0);

    // Rumah
    const houseCol = 9, houseRow = 3;
    const houseTile = tileToWorld(houseCol, houseRow);
    this.house = this.add.image(houseTile.x, houseTile.y, 'house')
      .setOrigin(0.5, 1)
      .setScale(SPRITE_SCALE)
      .setDepth(depthForY(houseTile.y, -0.2));

    this.houseCollider = this.physics.add.staticSprite(houseTile.x, houseTile.y - 24)
      .setSize(120, 48)
      .setVisible(false);

    // NPC "Teman"
    const friendTile = tileToWorld(11, 5);
    this.friend = this.physics.add.sprite(friendTile.x, friendTile.y, 'fplayer-idle')
      .setScale(SPRITE_SCALE)
      .setDepth(depthForY(friendTile.y))
      .setImmovable(true);
    this.friend.body.setSize(16, 16);
    this.friend.body.setOffset(16, 28);

    if (!this.anims.exists('f-idle-down')) {
      this.anims.create({
        key: 'f-idle-down',
        frames: this.anims.generateFrameNumbers('fplayer-idle', { start: 0, end: 3 }),
        frameRate: 6,
        repeat: -1
      });
    }
    this.friend.play('f-idle-down');

    this.speechBubble = this.add.graphics().setDepth(depthForY(friendTile.y, 0.5));
    this.drawSpeechBubble(this.friend.x - 10, this.friend.y - 75);
    this.speechBubble.setVisible(false);
    if (this.speechExcl) this.speechExcl.setVisible(false);

    // Player
    const playerTile = tileToWorld(8, 9);
    this.player = this.physics.add.sprite(playerTile.x, playerTile.y, 'player-idle')
      .setScale(SPRITE_SCALE)
      .setCollideWorldBounds(true)
      .setDepth(200);
    this.player.body.setSize(16, 16);
    this.player.body.setOffset(16, 28);

    this.createPlayerAnimations();
    this.player.play('idle-down');
    this.lastDir = 'down';
    this.movementLocked = false;

    this.physics.add.collider(this.player, this.houseCollider);
    this.physics.add.collider(this.player, this.friend);
    this.physics.add.collider(this.player, this.treeColliders);
    if (this.fenceColliders) {
      this.physics.add.collider(this.player, this.fenceColliders);
    }

    this.cursors = this.input.keyboard.createCursorKeys();
    this.wasd = this.input.keyboard.addKeys({
      up: Phaser.Input.Keyboard.KeyCodes.W,
      down: Phaser.Input.Keyboard.KeyCodes.S,
      left: Phaser.Input.Keyboard.KeyCodes.A,
      right: Phaser.Input.Keyboard.KeyCodes.D
    });

    this.eKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.E);
    this.eKey.on('down', () => {
      if (this.dialogOpen) {
        this.events.emit('advance-dialog');
      } else {
        this.handleInteract();
      }
    });

    this.physics.world.setBounds(0, 0, worldW, worldH);
    this.cameras.main.setBounds(0, 0, worldW, worldH);
    this.cameras.main.startFollow(this.player, true, 0.08, 0.08);
    this.cameras.main.setZoom(1);

    this.scene.launch('HUDScene');
  }

  // ---------- Pohon: satu sprite utuh, bukan rakitan ----------
  placeTree(col, row) {
    const { x, y } = tileToWorld(col, row);
    const tree = this.add.image(x, y, 'terrain', 'tree_full')
      .setOrigin(0.5, 1)
      .setScale(SPRITE_SCALE)
      .setDepth(depthForY(y, 0.05));

    const collider = this.physics.add.staticSprite(x, y - 6)
      .setSize(28, 16)
      .setVisible(false);
    this.treeColliders.add(collider);
    return tree;
  }

  // ---------- Dekorasi umum dari Objects.png ----------
  placeDecor(col, row, frameName, scale = 1) {
    const { x, y } = tileToWorld(col, row);
    return this.add.image(x, y, 'objects', frameName)
      .setOrigin(0.5, 1)
      .setScale(SPRITE_SCALE * scale)
      .setDepth(depthForY(y));
  }

  // ---------- Pagar mengelilingi area persegi (colMin..colMax, rowMin..rowMax) ----------
  addFence(colMin, rowMin, colMax, rowMax) {
    this.fenceColliders = this.physics.add.staticGroup();
    const gateRow = Math.floor((rowMin + rowMax) / 2);

    const addPost = (col, row, frame) => {
      const { x, y } = tileToWorld(col, row);
      this.add.image(x, y, 'objects', frame)
        .setOrigin(0.5, 1)
        .setScale(SPRITE_SCALE)
        .setDepth(depthForY(y, 0.1));
      const c = this.fenceColliders.create(x, y - 10, null).setVisible(false);
      c.body.setSize(20, 14);
    };

    // Sisi atas & bawah
    for (let col = colMin + 1; col < colMax; col++) {
      addPost(col, rowMin, 'fence_wood');
      addPost(col, rowMax, 'fence_wood');
    }
    // Sisi kiri & kanan, dengan gap di sisi kiri sebagai pintu masuk
    for (let row = rowMin + 1; row < rowMax; row++) {
      if (row !== gateRow) addPost(colMin, row, 'fence_stone');
      addPost(colMax, row, 'fence_stone');
    }
    // Pojok
    addPost(colMin, rowMin, 'post_single');
    addPost(colMax, rowMin, 'post_single');
    addPost(colMin, rowMax, 'post_single');
    addPost(colMax, rowMax, 'post_single');
  }

  createPlayerAnimations() {
    if (this.anims.exists('walk-down')) return;
    const frameRate = 8;
    const a = PLAYER_CONFIG.anims;

    ['down', 'left', 'right', 'up'].forEach((dir) => {
      this.anims.create({
        key: `idle-${dir}`,
        frames: this.anims.generateFrameNumbers('player-idle', { start: a[dir][0], end: a[dir][1] }),
        frameRate, repeat: -1
      });
      this.anims.create({
        key: `walk-${dir}`,
        frames: this.anims.generateFrameNumbers('player-walk', { start: a[dir][0], end: a[dir][1] }),
        frameRate, repeat: -1
      });
    });
  }

  createFarmPlots() {
    this.plotGraphics = [];
    GameState.plots.forEach((plot) => {
      const graphics = this.add.graphics().setDepth(3);
      this.drawPlotGraphics(graphics, plot);
      this.plotGraphics[plot.id] = graphics;
      this.updatePlotSprite(plot);
    });
  }

  drawPlotGraphics(graphics, plot) {
    graphics.clear();
    const isWatered = plot.state === 'watered';
    const fillColor = isWatered ? 0x5c3e21 : 0x8b5e3c;
    const borderColor = isWatered ? 0x3d2714 : 0x5c3e21;
    const cx = plot.x;
    const cy = plot.y - 16;

    graphics.fillStyle(fillColor, 0.9);
    graphics.beginPath();
    graphics.moveTo(cx, cy - 14);
    graphics.lineTo(cx + 28, cy);
    graphics.lineTo(cx, cy + 14);
    graphics.lineTo(cx - 28, cy);
    graphics.closePath();
    graphics.fillPath();

    graphics.lineStyle(2, borderColor, 1);
    graphics.beginPath();
    graphics.moveTo(cx, cy - 14);
    graphics.lineTo(cx + 28, cy);
    graphics.lineTo(cx, cy + 14);
    graphics.lineTo(cx - 28, cy);
    graphics.closePath();
    graphics.strokePath();
  }

  updatePlotSprite(plot) {
    if (plot.sprite) {
      plot.sprite.destroy();
      plot.sprite = null;
    }
    const graphics = this.plotGraphics[plot.id];
    if (graphics) this.drawPlotGraphics(graphics, plot);

    const cy = plot.y - 16;
    let frame = null;
    if (plot.state === 'planted') frame = 'crop_stage_1';
    else if (plot.state === 'watered') frame = 'crop_stage_2';
    else if (plot.state === 'ready') frame = 'crop_stage_4';

    if (frame) {
      plot.sprite = this.add.image(plot.x, cy, 'terrain', frame)
        .setOrigin(0.5, 1)
        .setScale(SPRITE_SCALE)
        .setDepth(depthForY(plot.y, 0.1));
      if (plot.state === 'watered') plot.sprite.setTint(0x99ccff);
    }
  }

  drawSpeechBubble(x, y) {
    this.speechBubble.clear();
    this.speechBubble.fillStyle(0xffffff, 1);
    this.speechBubble.fillRoundedRect(x, y, 20, 20, 5);
    this.speechBubble.lineStyle(1.5, 0x000000, 1);
    this.speechBubble.strokeRoundedRect(x, y, 20, 20, 5);

    if (this.speechExcl) this.speechExcl.destroy();
    this.speechExcl = this.add.text(x + 10, y + 10, '!', {
      fontSize: '12px', fontStyle: 'bold', color: '#000000'
    }).setOrigin(0.5).setDepth(this.speechBubble.depth + 1);
  }

  handleInteract() {
    if (this.dialogOpen) return;

    const distToFriend = Phaser.Math.Distance.Between(
      this.player.x, this.player.y, this.friend.x, this.friend.y
    );
    if (distToFriend < 60) {
      this.showDialog();
      return;
    }

    for (const plot of GameState.plots) {
      const dist = Phaser.Math.Distance.Between(this.player.x, this.player.y, plot.x, plot.y - 16);
      if (dist < 45) {
        this.handlePlotInteraction(plot);
        return;
      }
    }
  }

  showDialog() {
    if (this.dialogOpen) return;
    this.dialogOpen = true;
    this.player.setVelocity(0, 0);
    this.player.anims.play(`idle-${this.lastDir}`);
    this.movementLocked = true;

    GameState.addProgress(4);

    const lines = [
      'Hei, akhirnya kamu bangun juga. Ladang ini butuh sedikit perhatian.',
      'Mulailah dengan menanam beberapa benih. Tanahnya sudah siap untukmu.',
      'Kembalilah setelah memanen sesuatu, aku punya hadiah untukmu! 🎁'
    ];
    let lineIndex = 0;

    const cam = this.cameras.main;
    const sw = cam.width;
    const sh = cam.height;

    const dialogWidth = Math.min(sw - 80, 720);
    const dialogHeight = 140;
    const dialogX = sw / 2 - dialogWidth / 2;
    const dialogY = sh * 0.72 - dialogHeight / 2;

    const dialogBg = this.add.graphics().setScrollFactor(0).setDepth(20000);
    dialogBg.fillStyle(0x0f172a, 0.96);
    dialogBg.fillRoundedRect(dialogX, dialogY, dialogWidth, dialogHeight, 16);
    dialogBg.lineStyle(2.5, 0xe8a838, 1);
    dialogBg.strokeRoundedRect(dialogX, dialogY, dialogWidth, dialogHeight, 16);

    const nameText = this.add.text(dialogX + 24, dialogY + 18, '🌿 Teman', {
      fontSize: '15px', fontStyle: 'bold', color: '#f5c45e', fontFamily: 'Arial'
    }).setScrollFactor(0).setDepth(20001);

    const dialogText = this.add.text(dialogX + 24, dialogY + 50, '', {
      fontSize: '13px', color: '#ffffff', fontFamily: 'Arial',
      wordWrap: { width: dialogWidth - 48 }, lineSpacing: 5
    }).setScrollFactor(0).setDepth(20001);

    const btnWidth = 110, btnHeight = 28;
    const btnX = dialogX + dialogWidth - btnWidth - 24;
    const btnY = dialogY + dialogHeight - btnHeight - 16;

    const btnBg = this.add.graphics().setScrollFactor(0).setDepth(20001);
    btnBg.fillStyle(0xe8a838, 1);
    btnBg.fillRoundedRect(btnX, btnY, btnWidth, btnHeight, 8);

    const btnText = this.add.text(btnX + btnWidth / 2, btnY + btnHeight / 2, 'Lanjut ▶', {
      fontSize: '11px', color: '#ffffff', fontStyle: 'bold', fontFamily: 'Arial'
    }).setOrigin(0.5).setScrollFactor(0).setDepth(20002);

    const hintText = this.add.text(dialogX + 24, dialogY + dialogHeight - 28, 'Tekan E untuk lanjut', {
      fontSize: '11px', color: '#94a3b8', fontFamily: 'Arial', fontStyle: 'italic'
    }).setScrollFactor(0).setDepth(20001);

    let typeTimer = null;
    const typewriteLine = (text) => {
      dialogText.setText('');
      let i = 0;
      if (typeTimer) typeTimer.remove();
      typeTimer = this.time.addEvent({
        delay: 28,
        repeat: text.length - 1,
        callback: () => {
          dialogText.setText(text.substring(0, i + 1));
          i++;
        }
      });
    };
    typewriteLine(lines[0]);

    const btnZone = this.add.zone(btnX + btnWidth / 2, btnY + btnHeight / 2, btnWidth, btnHeight)
      .setScrollFactor(0).setDepth(20003).setInteractive({ useHandCursor: true });

    const advanceDialogue = () => {
      lineIndex++;
      if (lineIndex < lines.length) {
        typewriteLine(lines[lineIndex]);
        if (lineIndex === lines.length - 1) btnText.setText('Tutup ✕');
      } else {
        if (typeTimer) typeTimer.remove();
        dialogBg.destroy();
        nameText.destroy();
        dialogText.destroy();
        btnBg.destroy();
        btnText.destroy();
        btnZone.destroy();
        hintText.destroy();
        this.events.off('advance-dialog', advanceDialogue);

        this.time.delayedCall(100, () => {
          this.dialogOpen = false;
          this.movementLocked = false;
        });

        GameState.inventory.turnip_seed += 3;
        this.showFloatingText(this.friend.x, this.friend.y - 40, '+3 Benih Lobak 🎁', '#f5c45e');
      }
    };

    btnZone.on('pointerup', advanceDialogue);
    this.events.on('advance-dialog', advanceDialogue);
  }

  handlePlotInteraction(plot) {
    const cy = plot.y - 16;

    if (plot.state === 'empty') {
      const tSeed = GameState.inventory.turnip_seed;
      const pSeed = GameState.inventory.potato_seed;
      if (tSeed === 0 && pSeed === 0) {
        this.showFloatingText(this.player.x, this.player.y - 20, 'Tidak ada benih!', '#ef4444');
        return;
      }
      this.showPlantMenu(plot);
    } else if (plot.state === 'planted') {
      if (GameState.energy < 5) {
        this.showFloatingText(this.player.x, this.player.y - 20, 'Tenaga Habis!', '#ef4444');
        return;
      }
      plot.state = 'watered';
      GameState.energy -= 5;
      GameState.hasWateredToday = true;
      this.updatePlotSprite(plot);

      const splash = this.add.circle(plot.x, cy, 12, 0x3b82f6, 0.7).setDepth(depthForY(plot.y, 0.2));
      this.tweens.add({
        targets: splash, scaleX: 2, scaleY: 2, alpha: 0, duration: 400,
        onComplete: () => splash.destroy()
      });
      this.showFloatingText(plot.x, cy - 15, 'Disiram 💧', '#60a5fa');
    } else if (plot.state === 'ready') {
      const crop = plot.crop;
      GameState.inventory[crop] += 1;
      plot.state = 'empty';
      plot.crop = null;
      plot.daysGrown = 0;
      this.updatePlotSprite(plot);
      GameState.addProgress(2, 1);

      const name = crop === 'turnip' ? 'Lobak' : 'Kentang';
      this.showFloatingText(plot.x, cy - 15, `+1 ${name} ✂`, '#4ade80');

      for (let i = 0; i < 5; i++) {
        const spark = this.add.circle(plot.x, cy, 3, 0xfef08a, 0.9).setDepth(depthForY(plot.y, 0.2));
        const vx = Phaser.Math.Between(-40, 40);
        const vy = Phaser.Math.Between(-40, 40);
        this.tweens.add({
          targets: spark, x: plot.x + vx, y: cy + vy, alpha: 0, duration: 500,
          onComplete: () => spark.destroy()
        });
      }
    }
  }

  showPlantMenu(plot) {
    this.movementLocked = true;
    this.player.setVelocity(0, 0);
    this.player.anims.play(`idle-${this.lastDir}`);

    const menu = this.add.container(plot.x, plot.y - 45).setDepth(300);
    this.activePlantMenu = menu;

    const bg = this.add.graphics();
    bg.fillStyle(0x0f172a, 0.95);
    bg.fillRoundedRect(-75, -30, 150, 60, 8);
    bg.lineStyle(1.5, 0x475569, 1);
    bg.strokeRoundedRect(-75, -30, 150, 60, 8);
    menu.add(bg);

    const tSeed = GameState.inventory.turnip_seed;
    const pSeed = GameState.inventory.potato_seed;

    const tText = this.add.text(0, -15, `1: Tanam Lobak 🌱 (${tSeed})`, {
      fontSize: '9px', fontFamily: 'Arial', color: tSeed > 0 ? '#ffffff' : '#64748b'
    }).setOrigin(0.5).setInteractive({ useHandCursor: tSeed > 0 });

    const pText = this.add.text(0, 12, `2: Tanam Kentang 🥔 (${pSeed})`, {
      fontSize: '9px', fontFamily: 'Arial', color: pSeed > 0 ? '#ffffff' : '#64748b'
    }).setOrigin(0.5).setInteractive({ useHandCursor: pSeed > 0 });

    menu.add([tText, pText]);

    const closeMenu = () => {
      this.movementLocked = false;
      this.activePlantMenu = null;
      menu.destroy();
      this.input.keyboard.off('keydown-ONE');
      this.input.keyboard.off('keydown-TWO');
    };

    const plantCrop = (crop) => {
      plot.state = 'planted';
      plot.crop = crop;
      plot.daysGrown = 0;
      GameState.inventory[`${crop}_seed`] -= 1;
      this.updatePlotSprite(plot);
      GameState.addProgress(0, 1);

      const name = crop === 'turnip' ? 'Lobak' : 'Kentang';
      this.showFloatingText(plot.x, plot.y - 30, `${name} Ditanam!`, '#cbd5e1');
      closeMenu();
    };

    if (tSeed > 0) tText.on('pointerdown', () => plantCrop('turnip'));
    if (pSeed > 0) pText.on('pointerdown', () => plantCrop('potato'));

    this.input.keyboard.once('keydown-ONE', () => { if (tSeed > 0) plantCrop('turnip'); });
    this.input.keyboard.once('keydown-TWO', () => { if (pSeed > 0) plantCrop('potato'); });

    this.input.once('pointerdown', (pointer) => {
      const dist = Phaser.Math.Distance.Between(pointer.worldX, pointer.worldY, plot.x, plot.y);
      if (dist > 45 && this.activePlantMenu === menu) closeMenu();
    });
  }

  update() {
    if (this.movementLocked) {
      this.player.setVelocity(0, 0);
      return;
    }

    const spd = 200;
    const L = this.cursors.left.isDown || this.wasd.left.isDown;
    const R = this.cursors.right.isDown || this.wasd.right.isDown;
    const U = this.cursors.up.isDown || this.wasd.up.isDown;
    const D = this.cursors.down.isDown || this.wasd.down.isDown;

    let vx = (R ? spd : 0) - (L ? spd : 0);
    let vy = (D ? spd : 0) - (U ? spd : 0);
    if (vx !== 0 && vy !== 0) { vx *= 0.707; vy *= 0.707; }
    this.player.setVelocity(vx, vy);

    if (vx !== 0 || vy !== 0) {
      if (Math.abs(vx) >= Math.abs(vy)) this.lastDir = vx < 0 ? 'left' : 'right';
      else this.lastDir = vy < 0 ? 'up' : 'down';
      this.player.anims.play(`walk-${this.lastDir}`, true);
    } else {
      this.player.setVelocity(0, 0);
      this.player.anims.play(`idle-${this.lastDir}`, true);
    }

    this.player.setDepth(depthForY(this.player.y));
    if (this.friend) this.friend.setDepth(depthForY(this.friend.y));

    const distToFriend = Phaser.Math.Distance.Between(
      this.player.x, this.player.y, this.friend.x, this.friend.y
    );
    const showBubble = distToFriend < 80 && !this.dialogOpen;
    this.speechBubble.setVisible(showBubble);
    if (this.speechExcl) this.speechExcl.setVisible(showBubble);
  }

  showFloatingText(x, y, text, color = '#ffffff') {
    const t = this.add.text(x, y, text, {
      fontSize: '12px', color, fontStyle: 'bold', stroke: '#000000', strokeThickness: 3
    });
    t.setDepth(1000);
    this.tweens.add({
      targets: t, y: y - 30, alpha: 0, duration: 1200, ease: 'Power2',
      onComplete: () => t.destroy()
    });
  }
}